﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterPipe.DataStructure
{
    /// <summary>
    /// Classe que representa um arco.
    /// </summary>
    public class Edge
    {

        #region Propriedades

        /// <summary>
        /// O arco da rede, quando este pertencer ao grafo residual.
        /// </summary>
        public Edge NetworkEdge { get; set; }
        /// <summary>
        /// O nó de origem do arco.
        /// </summary>
        public Node From {get; private set;}
        /// <summary>
        /// O nó de destino do arco.
        /// </summary>
        public Node To { get; private set; }
        /// <summary>
        /// A capacidae associada ao arco.
        /// </summary>
        public int Capacity { get; set; }
        /// <summary>
        /// A capacidae usada do arco.
        /// </summary>
        public int UsedCapacity { get; private set; }

        #endregion

        #region  Construtores

        /// <summary>
        /// Cria um novo arco entre dois nós.
        /// </summary>
        /// <param name="from">O nó origem do arco.</param>
        /// <param name="to">O nó destino do arco.</param>
        /// <param name="cost">O custo associado ao arco.</param>
        public Edge(Node from, Node to) : this(from, to, 0)
        {
        }

        /// <summary>
        /// Cria um novo arco entre dois nós.
        /// </summary>
        /// <param name="from">O nó origem do arco.</param>
        /// <param name="to">O nó destino do arco.</param>
        /// <param name="capacity">O custo associado ao arco.</param>
        public Edge(Node from, Node to, int capacity)
        {
            this.From = from;
            this.To = to;
            this.Capacity = capacity;
        }

        #endregion

        #region Métodos

        /// <summary>
        /// Consome parte da capacidade do arco.
        /// </summary>
        /// <param name="flow">A quantidade de fluxo a consumir.</param>
        public void Consume(int flow)
        {
            this.UsedCapacity += flow;
        }

        /// <summary>
        /// Restaura a capacidade do arco.
        /// </summary>
        public void ResetCapacity()
        {
            this.UsedCapacity = 0;
        }

        #endregion

        #region Métodos Sobrescritos

        /// <summary>
        /// Apresenta a visualização do objeto em formato texto.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return String.Format("({0}/{1})", this.UsedCapacity, this.Capacity);
        }

        #endregion

    }
}
