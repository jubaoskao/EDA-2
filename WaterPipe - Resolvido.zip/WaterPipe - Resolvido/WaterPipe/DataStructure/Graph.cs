﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterPipe.DataStructure
{
    /// <summary>
    /// Classe que representa um grafo.
    /// </summary>
    public class Graph
    {

        #region Atributos

        /// <summary>
        /// Lista de nós que compõe o grafo.
        /// </summary>
        private List<Node> nodes;

        #endregion

        #region Propridades

        /// <summary>
        /// Mostra todos os nós do grafo.
        /// </summary>
        public Node[] Nodes
        {
            get { return this.nodes.ToArray(); }
        }

        #endregion

        #region Construtores

        /// <summary>
        /// Cria nova instância do grafo.
        /// </summary>
        public Graph()
        {
            this.nodes = new List<Node>();
        }

        #endregion

        #region Métodos

        #region Operações Grafo

        /// <summary>
        /// Encontra o nó através do seu nome.
        /// </summary>
        /// <param name="name">O nome do nó.</param>
        /// <returns>O nó encontrado ou nulo caso não encontre nada.</returns>
        public Node Find(string name)
        {
            //return this.nodes.SingleOrDefault(e => e.Name == name);
            foreach (Node node in this.nodes)
            {
                if (node.Name == name)
                {
                    return node;
                }
            }
            return null;
        }

        /// <summary>
        /// Encontra os arcos partindo de uma origem a um destino.
        /// </summary>
        /// <param name="from">O nó origem.</param>
        /// <param name="to">O nó destino.</param>
        /// <returns>A lista de nós encontrada.</returns>
        public List<Edge> Find(string from, string to)
        {
            var edges = new List<Edge>();
            foreach(var node in this.nodes)
            {
                var result = node.Edges.Where(e => e.From.Name == from && e.To.Name == to);
                if(result != null)
                {
                    edges.AddRange(result);
                }
            }
            return edges;
        }

        /// <summary>
        /// Adiciona um nó ao grafo.
        /// </summary>
        /// <param name="name">O nome do nó a ser adicionado.</param>
        /// <param name="info">A informação a ser armazenada no nó.</param>
        public void AddNode(string name)
        {
            AddNode(name, null);
        }

        /// <summary>
        /// Adiciona um nó ao grafo.
        /// </summary>
        /// <param name="name">O nome do nó a ser adicionado.</param>
        /// <param name="info">A informação a ser armazenada no nó.</param>
        public void AddNode(string name, object info)
        {
            if (Find(name) != null)
            {
                throw new Exception("Um nó com o mesmo nome já foi adicionado a este grafo.");
            }
            this.nodes.Add(new Node(name, info));
        }

        /// <summary>
        /// Remove um arco do grafo.
        /// </summary>
        /// <param name="edge">O arco do grafo.</param>
        public void RemoveEdge(Edge edge)
        {
            var node = Find(edge.From.Name);
            node.RemoveEdge(edge);
        }

        /// <summary>
        /// Remove um nó do grafo.
        /// </summary>
        /// <param name="name">O nome do nó a ser removido.</param>
        public void RemoveNode(string name)
        {
            Node existingNode = Find(name);
            if (existingNode == null)
            {
                throw new Exception("Não foi possível encontrar o nó a ser removido.");
            }
            this.nodes.Remove(existingNode);
        }

        /// <summary>
        /// Adiciona o arco entre dois nós associando determinado custo.
        /// </summary>
        /// <param name="from">O nó de origem.</param>
        /// <param name="to">O nó de destino.</param>
        /// <param name="capacity">O cust associado.</param>
        public void AddEdge(string from, string to, int capacity, Edge networkEdge = null)
        {
            Node start = Find(from);
            Node end = Find(to);
            // Verifica se os nós existem..
            if (start == null)
            {
                throw new Exception("Não foi possível encontrar o nó origem no grafo.");
            }
            if (end == null)
            {
                throw new Exception("Não foi possível encontrar o nó destino no grafo.");
            }
            start.AddEdge(end, capacity, networkEdge);
        }

        /// <summary>
        /// Obtem todos os nós vizinhos de determinado nó.
        /// </summary>
        /// <param name="node">O nó origem.</param>
        /// <returns></returns>
        public Node[] GetNeighbours(string from)
        {
            Node node = Find(from);
            // Verifica se os nós existem..
            if (node == null)
            {
                throw new Exception("Não foi possível encontrar o nó origem no grafo.");
            }
            List<Node> neighbours = new List<Node>();
            foreach (Edge edge in node.Edges)
            {
                neighbours.Add(edge.To);
            }
            return neighbours.ToArray();
            //return node.Edges.Select(e => e.To).ToArray();
        }

        /// <summary>
        /// Valida um caminho, retornando a lista de nós pelos quais ele passou.
        /// </summary>
        /// <param name="nodes">A lista de nós por onde passou.</param>
        /// <param name="path">O nome de cada nó na ordem que devem ser encontrados.</param>
        /// <returns></returns>
        public bool IsValidPath(ref Node[] nodes, params string[] path)
        {
            // Caso em que um caminho não é especificado..
            nodes = null;
            if (path == null || path.Length == 0)
            {
                return false;
            }
            // Cria lista para armazenar os nós por onde passou..
            List<Node> pathNodes = new List<Node>();
            // Recupera o nó origem do caminho..
            Node currentNode = Find(path[0]);
            if (currentNode == null)
            {
                throw new Exception(String.Format("Não foi possível encontrar o nó '{0}' no grafo.", path[0]));
            }
            for(int i=1; i<path.Length; i++)
            {
                pathNodes.Add(currentNode);
                // Garante existência do nó..
                if (Find(path[i]) == null)
                {
                    throw new Exception(String.Format("Não foi possível encontrar o nó '{0}' no grafo.", path[i]));
                }
                // Busca nó nos arcos destino..
                Node node = null;
                foreach (Edge edge in currentNode.Edges)
                {
                    if (edge.To.Name == path[i])
                    {
                        node = edge.To;
                    }
                }
                //Node node = currentNode.Edges.Where(e => e.To.Name == path[i]).Select(e => e.To).SingleOrDefault();
                if (node == null)
                {
                    nodes = pathNodes.ToArray();
                    return false;
                }
                currentNode = node;
            }
            pathNodes.Add(currentNode);
            nodes = pathNodes.ToArray();
            return true;
        }

        /// <summary>
        /// Marca um nó como visitado e retorna o caminho.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public Node Visit(string name)
        {
            var node = Find(name);
            node.Visited = true;
            return node;
        }

        #endregion

        #region Busca e Caminhos

        /// <summary>
        /// Limpa a marcação de nós visitados.
        /// </summary>
        public void ClearVisitedNodes()
        {
            foreach(Node node in nodes)
            {
                node.Visited = false;
            }
        }

        /// <summary>
        /// Executa o caminho em profundidade buscando o nó alvo.
        /// </summary>
        /// <param name="startNode">O nó inicio.</param>
        /// <returns>A lista de nós visitada.</returns>
        public List<Node> DepthFirstSearch(string startNode)
        {
            List<Node> path = new List<Node>();
            Stack<Node> stack = new Stack<Node>();
            Node start = Find(startNode);
            stack.Push(start);
            // Percorre enquanto não vazio..
            while(stack.Count > 0)
            {
                Node node = stack.Pop();
                if (!node.Visited)
                {
                    path.Add(node);
                    node.Visited = true;
                    foreach(Edge e in node.Edges)
                    {
                        if(!e.To.Visited)
                        {
                            stack.Push(e.To);
                        }
                    }
                }
            }
            return path;
        }

        /// <summary>
        /// Executa o caminho em largura buscando o nó alvo.
        /// </summary>
        /// <param name="startNode">O nó inicio.</param>
        /// <returns>A lista de nós visitada.</returns>
        public List<Node> BreadthFirstSearch(string startNode)
        {
            List<Node> path = new List<Node>();
            Queue<Node> queue = new Queue<Node>();
            Node start = Find(startNode);
            queue.Enqueue(start);
            // Percorre enquanto não vazio..
            while (queue.Count > 0)
            {
                Node node = queue.Dequeue();
                if (!node.Visited)
                {
                    path.Add(node);
                    node.Visited = true;
                    foreach (Edge e in node.Edges)
                    {
                        if (!e.To.Visited)
                        {
                            queue.Enqueue(e.To);
                        }
                    }
                }
            }
            return path;
        }

        /// <summary>
        /// Executa o algoritmo de caminho mínimo (Djkistra) buscando o nó alvo.
        /// </summary>
        /// <param name="startNode">O nó inicio.</param>
        /// <param name="targetNode">O nó alvo.</param>
        /// <returns>A lista de nós visitada.</returns>
        public List<Node> ShortestPath(string startNode, string targetNode)
        {
            ClearVisitedNodes();
            Node start = this.Find(startNode);
            start.Visited = true;
            // Cria grafo solução..
            Graph solution = new Graph();
            solution.AddNode(startNode, 0);
            // Cria variáveil de controle..
            bool hasSolution = solution.Find(targetNode) != null;
            while(!hasSolution)
            {
                double min = Double.PositiveInfinity;
                Edge minEdge = null;
                foreach(Node solutionNode in solution.Nodes)
                {
                    double currentCost = Convert.ToDouble(solutionNode.Info);
                    // Busca informação no grafo origem..
                    Node node = this.Find(solutionNode.Name);
                    foreach(Edge edge in node.Edges)
                    {
                        if(currentCost + edge.Capacity < min && solution.Find(edge.To.Name) == null)
                        {
                            min = currentCost + edge.Capacity;
                            minEdge = edge;
                        }
                    }
                }
                if(minEdge != null)
                {
                    solution.AddNode(minEdge.To.Name, min);
                    solution.AddEdge(minEdge.To.Name, minEdge.From.Name, minEdge.Capacity);
                    hasSolution = (minEdge.To.Name == targetNode);
                }
                else
                {
                    return null;
                }
            }
            Stack<Node> path = new Stack<Node>();
            // Faz o caminho inverso..
            Node resultNode = solution.Find(targetNode);
            while(resultNode.Edges != null && resultNode.Edges.Count > 0)
            {
                path.Push(resultNode);
                resultNode = resultNode.Edges[0].To;
            }
            path.Push(resultNode);
            return path.ToList();
        }

        #endregion

        #region MST

        /// <summary>
        /// Create a MST using Kruskal.
        /// </summary>
        /// <returns></returns>
        public Graph MstKruskal()
        {
            // Adiciona todos os arcos..
            List<Edge> edges = new List<Edge>();
            foreach(Node node in this.Nodes)
            {
                edges.AddRange(node.Edges);
            }
            // Orderna pelo custo..
            edges = edges.OrderBy(e => e.Capacity).ToList();
            Graph solution = new Graph();
            foreach(Edge edge in edges)
            {
                AddKruskalEdge(edge, solution);
            }
            return solution;
        }

        /// <summary>
        /// Adiciona um arco no grafo solução usando Kruskal.
        /// </summary>
        /// <param name="edge"></param>
        /// <param name="graph"></param>
        private void AddKruskalEdge(Edge edge, Graph graph)
        {
            // Get nodes..
            Node from = graph.Find(edge.From.Name);
            Node to = graph.Find(edge.To.Name);
            if (from == null)
            {
                graph.AddNode(edge.From.Name);
                from = graph.Find(edge.From.Name);
            }
            if (to == null)
            {
                graph.AddNode(edge.To.Name);
                to = graph.Find(edge.To.Name);
            }
            Node parentTo = graph.FindParent(from);
            Node parentFrom = graph.FindParent(to);
            if(parentTo.Name != parentFrom.Name)
            {
                graph.AddEdge(edge.From.Name, edge.To.Name, edge.Capacity);
                graph.AddEdge(edge.From.Name, edge.To.Name, edge.Capacity);
                parentTo.Info = parentFrom;
            }
        }

        /// <summary>
        /// Encontra o nó pai atual a partir do info.
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        private Node FindParent(Node node)
        {
            while(node.Info != null && node.Info is Node)
            {
                node = node.Info as Node;
            }
            return node;
        }

        #endregion

        #endregion

    }
}
