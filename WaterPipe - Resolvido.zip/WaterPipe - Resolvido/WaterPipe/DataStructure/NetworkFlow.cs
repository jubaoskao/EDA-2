﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WaterPipe.DataStructure
{
    /// <summary>
    /// Classe que representa um fluxo em redes.
    /// </summary>
    public class NetworkFlow
    {

        #region Propriedades

        /// <summary>
        /// O grafo origem do fluxo de redes.
        /// </summary>
        public Graph Network { get; private set; }
        /// <summary>
        /// O grafo residual calculado durante a análise.
        /// </summary>
        public Graph Residual { get; private set; }

        #endregion

        #region Construtores

        /// <summary>
        /// Cria novo fluxo em redes.
        /// </summary>
        public NetworkFlow()
        {
            this.Network = new Graph();
        }

        #endregion

        #region Métodos

        /// <summary>
        /// Adiciona um nó no fluxo.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="info"></param>
        public void AddNode(string name, object info = null)
        {
            this.Network.AddNode(name, info);
        }

        /// <summary>
        /// Adiciona um arco ao fluxo.
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="capacity"></param>
        public void AddEdge(string from, string to, int capacity = 0)
        {
            this.Network.AddEdge(from, to, capacity);
        }

        /// <summary>
        /// Analisa o fluxo e calcula as informações.
        /// </summary>
        /// <param name="source">O nó origem.</param>
        /// <param name="sink">O nó destino.</param>
        public int MaxFlow(string source, string sink)
        {
            BuildResidualGraph();
            // Executa enquanto houverem caminhos..
            var maxFlow = 0;
            var path = GetResidualPath(source, sink);
            while (path != null)
            {
                var flow = path.Min(e => e.Capacity);
                // Consome parte do fluxo no grafo origem..
                foreach (var edge in path)
                {
                    // Consome fluxo no nó origem..
                    if (edge.NetworkEdge != null)
                    {
                        edge.NetworkEdge.Consume(flow);
                    }
                    // Atualiza o grafo residual..
                    UpdateResidualGraph(edge, flow);
                }
                maxFlow += flow;
                path = GetResidualPath(source, sink);
            }
            return maxFlow;
        }

        /// <summary>
        /// Analisa o fluxo e calcula as informações.
        /// </summary>
        /// <param name="source">O nó origem.</param>
        /// <param name="sink">O nó destino.</param>
        public List<Edge> CuttingEdges(string source, string sink, out int maxFlow)
        {
            var cuttingEdges = new List<Edge>();
            maxFlow = MaxFlow(source, sink);
            foreach (var node in this.Network.Nodes)
            {
                foreach (var edge in node.Edges)
                {
                    if (edge.UsedCapacity == edge.Capacity)
                    {
                        cuttingEdges.Add(edge);
                    }
                }
            }
            return cuttingEdges;
        }

        /// <summary>
        /// Atualiza o grafo residual, após a passagem de "flow" pelo arco.
        /// </summary>
        /// <param name="edge">O arco por onde o fluxo passou.</param>
        /// <param name="flow">O fluxo que passou pelo arco.</param>
        private void UpdateResidualGraph(Edge edge, int flow)
        {
            var edges = this.Residual.Find(edge.To.Name, edge.From.Name);
            // Para cada arco encontrado, aumentar seu fluxo..
            if (edges != null && edges.Count > 0)
            {
                edges[0].Capacity += flow;
            }
            else
            {
                this.Residual.AddEdge(edge.To.Name, edge.From.Name, flow);
            }
            // Atualiza a capacidade e remove o arco se necessário..
            edge.Capacity -= flow;
            if (edge.Capacity == 0)
            {
                this.Residual.RemoveEdge(edge);
            }
        }

        /// <summary>
        /// Constroi o grafo residual.
        /// </summary>
        private void BuildResidualGraph()
        {
            // Cria grafo residual..
            this.Residual = new Graph();
            foreach (var node in this.Network.Nodes)
            {
                this.Residual.AddNode(node.Name, node.Info);
            }
            foreach (var node in this.Network.Nodes)
            {
                foreach (var edge in node.Edges)
                {
                    edge.NetworkEdge = null;
                    edge.ResetCapacity();
                    this.Residual.AddEdge(edge.From.Name, edge.To.Name, edge.Capacity, edge);
                }
            }
        }

        /// <summary>
        /// Obtém um caminho de origem a destino no grafo residual.
        /// </summary>
        /// <returns>A lista de arcos que compõe o caminho.</returns>
        private List<Edge> GetResidualPath(string source, string sink)
        {
            // Limpa os nós visitados..
            foreach (var node in this.Residual.Nodes)
            {
                node.SourceEdge = null;
                node.Visited = false;
            }
            // Executa passeio em largura..
            var queue = new Queue<Node>();
            var sourceNode = this.Residual.Find(source);
            // Marca nó como visitado e adiciona a fila..
            sourceNode.Visited = true;
            queue.Enqueue(sourceNode);
            while (queue.Count > 0)
            {
                var node = queue.Dequeue();
                if (String.Compare(node.Name, sink, false) == 0)
                {
                    Stack<Edge> stack = new Stack<Edge>();
                    while (node.SourceEdge != null)
                    {
                        stack.Push(node.SourceEdge);
                        node = node.SourceEdge.From;
                    }
                    // Constroi o caminho..
                    return stack.ToList();
                }
                foreach (var edge in node.Edges)
                {
                    // Adiciona a fila e marca como visitado..
                    if (!edge.To.Visited)
                    {
                        queue.Enqueue(edge.To);
                        edge.To.Visited = true;
                        edge.To.SourceEdge = edge;
                    }
                }
            }
            return null;
        }

        #endregion

    }
}
