﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Glee = Microsoft.Glee.Drawing;
using GleeUI = Microsoft.Glee.GraphViewerGdi;
using EDA = WaterPipe.DataStructure;

namespace WaterPipe
{
    /// <summary>
    /// Implementação do form de visualização do grafo.
    /// </summary>
    public partial class GraphViewer : Form
    {

        #region Atributos

        /// <summary>
        /// A instância da rede a desenhar.
        /// </summary>
        private EDA.NetworkFlow network;

        #endregion

        #region Construtores

        /// <summary>
        /// Cria nova instância do form;
        /// </summary>
        public GraphViewer(EDA.NetworkFlow network)
        {
            this.network = network;
            InitializeComponent();
            DrawResidual();
        }

        #endregion

        #region Métodos

        /// <summary>
        /// Desenha o grafo atual.
        /// </summary>
        private void DrawResidual()
        {
            List<EDA.Edge> edges = new List<EDA.Edge>();
            Glee.Graph drawingGraph = new Glee.Graph("Grafo Residual");
            // Adiciona nós ao grafo..
            foreach (EDA.Node node in this.network.Residual.Nodes)
            {
                Glee.Node drawingNode = drawingGraph.AddNode(node.Name);
                drawingNode.Attr.Shape = Glee.Shape.Circle;
                if (node.Name == "s")
                {
                    drawingNode.Attr.Color = Glee.Color.Red;
                }
                if (node.Name == "t")
                {
                    drawingNode.Attr.Color = Glee.Color.Blue;
                }
                // Consolida os arcos..
                edges.AddRange(node.Edges);
            }
            foreach (EDA.Edge edge in edges)
            {
                Glee.Edge drawingEdge = drawingGraph.AddEdge(edge.From.Name, edge.To.Name);
                drawingEdge.Attr.Label = String.Format("{0}", edge.Capacity);
            }
            // Gera controle de desenho..
            GleeUI.GViewer viewer = new GleeUI.GViewer();
            viewer.NavigationVisible = false;
            viewer.OutsideAreaBrush = Brushes.White;
            viewer.RemoveToolbar();
            viewer.Graph = drawingGraph;
            viewer.Dock = System.Windows.Forms.DockStyle.Fill;
            pnlGraph.Controls.Clear();
            pnlGraph.Controls.Add(viewer);
        }

        #endregion

    }
}
