﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EDA = WaterPipe.DataStructure;
using Glee = Microsoft.Glee.Drawing;
using GleeUI = Microsoft.Glee.GraphViewerGdi;

namespace WaterPipe
{
    /// <summary>
    /// Código do form.
    /// </summary>
    public partial class Principal : Form
    {

        #region Atributos

        /// <summary>
        /// Classe que representa um fluxo em rede.
        /// </summary>
        private EDA.NetworkFlow network;

        #endregion

        #region Construtores

        /// <summary>
        /// Cria nova instância do form.
        /// </summary>
        public Principal()
        {
            InitializeComponent();
            Reset();
        }

        #endregion

        #region Métodos

        /// <summary>
        /// Cria a rede a ser exibida.
        /// </summary>
        private void CreateNetwork()
        {
            this.network = new EDA.NetworkFlow();
            this.network.AddNode("s");
            this.network.AddNode("a");
            this.network.AddNode("b");
            this.network.AddNode("c");
            this.network.AddNode("d");
            this.network.AddNode("t");
            this.network.AddEdge("s", "a", 16);
            this.network.AddEdge("s", "b", 13);
            this.network.AddEdge("a", "c", 12);
            this.network.AddEdge("a", "b", 10);
            this.network.AddEdge("b", "a", 4);
            this.network.AddEdge("b", "d", 14);
            this.network.AddEdge("c", "b", 9);
            this.network.AddEdge("c", "t", 20);
            this.network.AddEdge("d", "c", 7);
            this.network.AddEdge("d", "t", 4);
        }

        /// <summary>
        /// Desenha o grafo atual.
        /// </summary>
        private void DrawNetwork(List<EDA.Edge> cuttingEdges = null)
        {
            List<EDA.Edge> edges = new List<EDA.Edge>();
            Glee.Graph drawingGraph = new Glee.Graph("Rede");
            // Adiciona nós ao grafo..
            foreach (EDA.Node node in this.network.Network.Nodes)
            {
                Glee.Node drawingNode = drawingGraph.AddNode(node.Name);
                drawingNode.Attr.Shape = Glee.Shape.Circle;
                if (node.Name == "s")
                {
                    drawingNode.Attr.Color = Glee.Color.Red;
                }
                if (node.Name == "t")
                {
                    drawingNode.Attr.Color = Glee.Color.Blue;
                }
                // Consolida os arcos..
                edges.AddRange(node.Edges);
            }
            foreach (EDA.Edge edge in edges)
            {
                Glee.Edge drawingEdge = drawingGraph.AddEdge(edge.From.Name, edge.To.Name);
                drawingEdge.Attr.Label = String.Format("{0}/{1}", edge.UsedCapacity, edge.Capacity);
                // Marca os nós removidos..
                if(cuttingEdges != null && cuttingEdges.Contains(edge))
                {
                    drawingEdge.Attr.Color = Glee.Color.LightGray;
                }
            }
            // Gera controle de desenho..
            GleeUI.GViewer viewer = new GleeUI.GViewer();
            viewer.NavigationVisible = false;
            viewer.OutsideAreaBrush = Brushes.White;
            viewer.RemoveToolbar();
            viewer.Graph = drawingGraph;
            viewer.Dock = System.Windows.Forms.DockStyle.Fill;
            pnlGraph.Controls.Clear();
            pnlGraph.Controls.Add(viewer);
        }

        /// <summary>
        /// Executa o processamento e visualização dos dados.
        /// </summary>
        private void Run()
        {
            int maxFlow = 0;
            var cuttingEdges = this.network.CuttingEdges("s", "t", out maxFlow);
            MessageBox.Show(String.Format("Max Flow: {0}", maxFlow));
            DrawNetwork(cuttingEdges);
            GraphViewer viewer = new GraphViewer(this.network);
            viewer.ShowDialog();
        }

        /// <summary>
        /// Mostra o grafo original novamente.
        /// </summary>
        private void Reset()
        {
            CreateNetwork();
            DrawNetwork();
        }

        #endregion

        private void btnProcess_Click(object sender, EventArgs e)
        {
            Run();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {

        }

    }
}
