using System;
using System.Collections;
using System.Diagnostics;
using System.Collections.Generic;
using ProjetoGrafos.DataStructure;

namespace EP
{
 	

	/// <summary>
	/// EPAgent - searchs solution for the eight puzzle problem
	/// </summary>
	public class EightPuzzle: Graph
	{
		private int [] initState;
		private int [] target;
		
		/// <summary>
		/// Creating the agent and setting the initialstate plus target
		/// </summary>
		/// <param name="InitialState"></param>
		public EightPuzzle(int [] InitialState, int [] Target)
		{
			initState = InitialState;
			target = Target;
		}

		/// <summary>
		/// Accessor for the solution
		/// </summary>
		public int [] GetSolution()
		{
			return FindSolution();
		}

		/// <summary>
		/// Fun��o principal de busca
		/// </summary>
		/// <returns></returns>
		private int[] FindSolution()
		{
            return null;
		}

        /// <summary>
        /// Gera o ID de um n�
        /// </summary>
        /// <param name="v"></param>
        /// <returns></returns>
        private string GenerateID(int[] v)
        {
            string id = "";
            foreach (int i in v)
                id += i.ToString();
            return id;
        }


	}




}

