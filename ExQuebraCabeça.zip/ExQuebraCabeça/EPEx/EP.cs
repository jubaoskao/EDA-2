using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.Collections.Generic;
using ProjetoGrafos.DataStructure;

namespace EP
{
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public class EP : System.Windows.Forms.Form
    {
        private System.Windows.Forms.Button b00;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;
        private Button[,] BL;
        private System.Windows.Forms.Button btnSolve;
        private int x, y;
        private Button btnLimpar;
        private Button btnGrafo;
        private Graph grafo;

        public EP()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            // Draws the painel
            DrawPanel();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.b00 = new System.Windows.Forms.Button();
            this.btnSolve = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnGrafo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // b00
            // 
            this.b00.BackColor = System.Drawing.Color.White;
            this.b00.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.b00.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b00.Location = new System.Drawing.Point(8, 8);
            this.b00.Margin = new System.Windows.Forms.Padding(8);
            this.b00.Name = "b00";
            this.b00.Size = new System.Drawing.Size(56, 56);
            this.b00.TabIndex = 2;
            this.b00.UseVisualStyleBackColor = false;
            this.b00.Visible = false;
            this.b00.Click += new System.EventHandler(this.b00_Click);
            // 
            // btnSolve
            // 
            this.btnSolve.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSolve.Location = new System.Drawing.Point(23, 379);
            this.btnSolve.Name = "btnSolve";
            this.btnSolve.Size = new System.Drawing.Size(83, 28);
            this.btnSolve.TabIndex = 3;
            this.btnSolve.Text = "Solu��o";
            this.btnSolve.Click += new System.EventHandler(this.btnSolve_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(127, 379);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLimpar.Size = new System.Drawing.Size(79, 28);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnGrafo
            // 
            this.btnGrafo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGrafo.Location = new System.Drawing.Point(226, 379);
            this.btnGrafo.Name = "btnGrafo";
            this.btnGrafo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnGrafo.Size = new System.Drawing.Size(119, 28);
            this.btnGrafo.TabIndex = 5;
            this.btnGrafo.Text = "Criar Grafo";
            this.btnGrafo.Click += new System.EventHandler(this.btnGrafo_Click);
            // 
            // EP
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(357, 419);
            this.Controls.Add(this.btnGrafo);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnSolve);
            this.Controls.Add(this.b00);
            this.Name = "EP";
            this.Text = "Passeio do Cavalo - Knight\'s Tour";
            this.ResumeLayout(false);

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.Run(new EP());
        }

        /// <summary>
        /// Draws the game panel
        /// </summary>
        private void DrawPanel()
        {
            // Creating the labels
            BL = new Button[6, 6];
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    Button B = new Button();

                    B.Parent = b00.Parent;
                    B.Font = b00.Font;
                    B.Size = b00.Size;
                    B.Left = i * 56 + 10;
                    B.Top = j * 56 + 10;
                    if (i % 2 == 0 && j % 2 == 0 || i == j || (j % 2 != 0 && i % 2 != 0))
                        B.BackColor = b00.BackColor;
                    else
                        B.BackColor = Color.LightGray;
                    B.Visible = true;
                    B.Click += new System.EventHandler(this.b00_Click);
                    BL[i, j] = B;
                }
            }
        }

        /// <summary>
        /// Click template for all buttons 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void b00_Click(object sender, System.EventArgs e)
        {
            Button b = sender as Button;
            Image f = null;

            x = (b.Bounds.X / 56);  // Convertendo posi��o clique para Matriz.
            y = (b.Bounds.Y / 56);  // Convertendo posi��o clique para Matriz.

            if (b.BackColor == Color.LightGray)
            {
                f = Image.FromFile("C:\\Users\\saojuest\\Desktop\\ExQuebraCabe�a\\EPEx\\Imagens\\HORSECINZA.png");
            }
            else
            {
                f = Image.FromFile("C:\\Users\\saojuest\\Desktop\\ExQuebraCabe�a\\EPEx\\Imagens\\HORSE.png");
            }
            b.BackgroundImage = f;
        }

        public static void DrawNode(string nodeName, Color color, int delay)
        {
            string[] temp = nodeName.Split('-');
            int x = Convert.ToInt32(temp[0].Replace("N", ""));
            int y = Convert.ToInt32(temp[1]);

            Point p = new Point(x, y);

            //Bitmap b = pbMaze.Image as Bitmap;
            //Graphics g = Graphics.FromImage(b);

            Brush brush = new SolidBrush(color);
            //g.FillEllipse(brush, p.X * 25 + 5, p.Y * 25 + 5, 15, 15);

            //pbMaze.Refresh();
            Thread.Sleep(delay);
        }


        //private void DrawNodes(List<Node> path)
        //{
        //    if (path != null && path.Count > 0)
        //    {
        //        foreach (Node node in path)
        //        {
        //            DrawNode(node.Name, Color.Red, 100);
        //        }
        //    }
        //}

        /// <summary>
        /// Solves the puzzle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSolve_Click(object sender, System.EventArgs e)
        {
            //DrawNodes(g.HamiltonianPath());

            bool x = grafo.Hamiltonian();

            List<Node> n = null;
            if (n == null)
            {
                MessageBox.Show("Caminho n�o encontrado para passeio no Tabuleiro");
                return;
            }

            for (int i = 0; i < n.Count; i++)
            {
                for (int j = 0; j < n.Count; j++)
                {
                    Image f = null;
                    if (BL[i, j].BackColor == Color.LightGray)
                    {
                        f = Image.FromFile("C:\\Users\\saojuest\\Desktop\\ExQuebraCabe�a\\EPEx\\Imagens\\HORSECINZA.png");
                    }
                    else
                    {
                        f = Image.FromFile("C:\\Users\\saojuest\\Desktop\\ExQuebraCabe�a\\EPEx\\Imagens\\HORSE.png");
                    }
                    BL[i, j].BackgroundImage = f;
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    BL[i, j].BackgroundImage = null;
                }
            }
        }


        private void btnGrafo_Click(object sender, EventArgs e)
        {
            grafo = new Graph();

            // Adicionando n�s
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    string name = "N" + i.ToString() + "-" + j.ToString();
                    grafo.AddNode(name, i.ToString() + j.ToString());
                }
            }

            // Adicionando arcos
            foreach (Node item in grafo.Nodes)
            {
                foreach (Node it2 in grafo.Nodes)
                {
                    if (item.Name != it2.Name) item.AddEdge(it2);
                }
            }
        }
    }
}
